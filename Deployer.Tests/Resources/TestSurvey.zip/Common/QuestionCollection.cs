﻿using System;
using SurveyEngine.Core.Questions;
using SurveyEngine.Core.Repository;

namespace ChartDemo
{
    public class ChartDemoQuestionCollection : QuestionCollection
    {
        private Random _rnd = new Random((int) DateTime.Now.Ticks);

        protected override void InitializeQuestions() {

            Add(() => new SelectListQuestion<SelectListVariant>(GetQuestionData("Q1")) {
                OnAfterAsk = a => a.Data().Q1Answer = a.Question.Value.Value
            });

        }
    }
}