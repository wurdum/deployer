﻿using System;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ChartDemo.Common
{
    public class SurveyDatabaseInstaller
    {
        class DBInstallerContext
        {
            public string ConnectionString;
            public string DataBase;
            public string SqlScript;

            public DBInstallerContext(string conn, string db)
            {
                ConnectionString = conn;
                DataBase = db;
            }
        }

        public static void Install(string connectionString, string dbName)
        {
            DBInstallerContext context = new DBInstallerContext(connectionString, dbName);
            context.SqlScript = GetSqlScript(context);
            if (!char.IsSymbol(context.SqlScript[0]))//remove first character 65279
                context.SqlScript = context.SqlScript.Substring(1);
            SqlConnection dbConnection = null;

            try
            {
                using (dbConnection = new SqlConnection(context.ConnectionString))
                {
                    dbConnection.Open();
                    if (ISDBExists(dbConnection, context))
                    {
                        throw new InvalidOperationException(string.Format("DataBase with name '{0}' already exists!", context.DataBase));
                    }

                    string[] scriptParts = Regex.Split(context.SqlScript, @"[\r][\n]GO[\r][\n]|^GO[\r][\n]|[\r][\n]GO$", RegexOptions.IgnoreCase);

                    using (SqlCommand execScript = new SqlCommand("execute", dbConnection))
                    {
                        execScript.CommandType = CommandType.Text;
                        foreach (string script in scriptParts)
                        {                            
                            if (script.Length > 0)
                            {
                                execScript.CommandText = script;
                                execScript.CommandType = CommandType.Text;
                                execScript.ExecuteNonQuery();
                            }
                        }
                    }
                }
            }
            catch
            {
                if (dbConnection.State == ConnectionState.Open)
                    DeleteDB(dbConnection, context);
                throw;
            }
            finally
            {
                if (dbConnection.State != ConnectionState.Open)
                    dbConnection.Close();
            }
        }

        private static string GetSqlScript(DBInstallerContext context)
        {
            Assembly curAssembly = typeof(SurveyDatabaseInstaller).Assembly;
            string assemblyName = Regex.Split(curAssembly.FullName, @",\s*")[0];
            string sqlScript = "";
            using (Stream resourceStream = curAssembly.GetManifestResourceStream(assemblyName + ".DBScript.sql"))
            {
                byte[] bytes = new byte[resourceStream.Length];
                resourceStream.Read(bytes, 0, (int)resourceStream.Length);
                sqlScript = Encoding.UTF8.GetString(bytes.ToArray());
            }

            string[] replacements = new string[] { @"##DBNAME##" };

            return Regex.Replace(sqlScript, replacements[0], context.DataBase, RegexOptions.IgnoreCase);
        }

        private static void DeleteDB(SqlConnection conn, DBInstallerContext context)
        {
            SqlCommand createCommand = new SqlCommand("DROP DATABASE " + context.DataBase, conn);
            createCommand.ExecuteNonQuery();
        }

        private static bool ISDBExists(SqlConnection conn, DBInstallerContext context)
        {
            string cmdText = "select count(*) from master.dbo.sysdatabases where name= @QDBName";
            
            using (SqlCommand sqlCmd = new SqlCommand(cmdText, conn))
            {
                sqlCmd.Parameters.Add("@QDBName", SqlDbType.NVarChar).Value = context.DataBase;
                return ((int)sqlCmd.ExecuteScalar() > 0);
            }
        }
    }
}