﻿using SurveyEngine.Core.Parameters;
using SurveyEngine.Model;

namespace ChartDemo
{
    public class ChartDemoParameters : RespondentParametersBase<ChartDemoParameters>
    {
        public ChartDemoParameters(Respondent respondent) : base(respondent) {}

        public int Version {
            get { return GetValue(p => p.Version); }
            set { SetValue(p => p.Version, value); }
        }

        public int Q1Answer {
            get { return GetValue(p => p.Q1Answer); }
            set { SetValue(p => p.Q1Answer, value); }
        }
    }

    public static class RespondentHelper
    {
        public static ChartDemoParameters Data(this Respondent respondent) {
            return new ChartDemoParameters(respondent);
        }

        public static ChartDemoParameters Data(this ITypedQuestionEventArgs args) {
            return new ChartDemoParameters(args.BaseEventArgs.Respondent);
        }
    }
}