﻿using SurveyEngine.Core.Export;
using SurveyEngine.DataAccess.Sql;
using SurveyEngine.DataAccess;

namespace ChartDemo
{
    public class ChartDemoDataTableExport : DataTableExport2
    {
        public ChartDemoDataTableExport(SurveyDataContext dataContext, IQuestionRepository questionRepository) : base(dataContext, questionRepository) { }

        //protected override IEnumerable<KeyValuePair<int, string>> GetLabels(string sourceName) {
        //    return CSVDataReader.GetDataEx(sourceName).Select(r => new KeyValuePair<int, string>(r.Id, r.Text)).ToList();
        //}
    }
}
