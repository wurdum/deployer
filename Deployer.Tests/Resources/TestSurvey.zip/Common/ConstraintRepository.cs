﻿using System.Collections.Generic;
using System.Linq;
using ChartDemo.Data;
using SurveyEngine.DataAccess;
using SurveyEngine.Model;
using SurveyEngine.Core.Constraints;

namespace ChartDemo
{
    public class ConstraintRepository : ISurveyConstraintRepository
    {
        static List<IConstraint> _constraints;

        #region ISurveyConstraintRepository Members

        public IEnumerable<SurveyEngine.Model.IConstraint> GetConstraints() {
        
            return _constraints ?? LoadConstraints();
        }

        #endregion

        private static IEnumerable<SurveyEngine.Model.IConstraint> LoadConstraints() {
            _constraints = new List<IConstraint>();

            var collection = new ChartDemoQuestionCollection();
            var questions = collection.Select(q => q.Key).ToList();

            var answersConstraint = ParametersConstraint.Create<ChartDemoParameters>(
                "Answers", questions, p => new  { p.Q1Answer });

            foreach (var q1Variant in SurveyDataProvider.Q1Variants())
                answersConstraint.AddCondition(new {Q1Answer = q1Variant.Id}, 1, NotSatisfiedConditionAction.None);

            answersConstraint.AddPropertyValueDescriptions("Q1Answer", new Dictionary<string, string> {
                {"1", "Yes"},
                {"2", "No, and that's okay"},
                {"3", "No, but wish we were able to"}
            });

            _constraints.Add(answersConstraint);
            return _constraints;
        }
    }
}
