﻿using SurveyEngine.Core.Repository;

namespace ChartDemo
{
    public class ChartDemoQuestionRepository : QuestionRepository<ChartDemoQuestionCollection>
    {
    }
}
