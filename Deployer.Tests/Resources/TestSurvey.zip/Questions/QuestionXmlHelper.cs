﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Xml;
using System.ComponentModel;
using System.Reflection;
using SurveyEngine.Model;

namespace SurveyEngine.Core.Utils
{
    public static class QuestionXmlHelper
    {

        static readonly Type s_genericListType = typeof(List<>);
        public static void FillQuestion(this IQuestion question, XElement xdata) {

            Type questionType = question.GetType();
            var xFields = xdata.Elements("property").Where(x => x.Attribute("name") != null);

            // Запоняем поля
            foreach (var xProperty in xFields.Where(x => x.Attribute("type") == null || x.Attribute("type").Value != "collection")) {
                var property = questionType.GetProperty(xProperty.Attribute("name").Value);
                    try {
                        var value = ChangeType(xProperty.Value, property.PropertyType);
                        property.SetValue(question, value, null);
                    } catch (Exception e) {
                        throw new QuestionXmlHelperException("Failed creating", xProperty.Attribute("name").Value, xdata.Elements().First().Attribute("type").Value, xProperty.ToString(), e);
                    }
            }

            // Запоняем коллекции
            foreach (var xCollection in xFields.Where(x => x.Attribute("type") != null && x.Attribute("type").Value == "collection")) {
                var property = questionType.GetProperty(xCollection.Attribute("name").Value);
                Type itemType = property.PropertyType.GetGenericArguments().First();
                var list = (System.Collections.IList)property.GetValue(question, null); 

                foreach (var xItem in xCollection.Elements("item")) {
                    var item = Activator.CreateInstance(itemType);

                    foreach (var xProperty in xItem.Elements("property").Where(xp => xp.Attribute("name") != null)) {
                        try {

                            var itemProperty = itemType.GetProperty(xProperty.Attribute("name").Value);
                            itemProperty.SetValue(item, ChangeType(xProperty.Value, itemProperty.PropertyType), null);
                        } catch (Exception e) {
                            throw new QuestionXmlHelperException("Failed creating", xProperty.Attribute("name").Value, xdata.Elements().First().Attribute("type").Value, xProperty.ToString(), e);
                        }
                    }
                    list.Add(item);
                }
            }

        }
        public static object ChangeType(object value, Type conversionType) {
            if (conversionType == null) {
                throw new ArgumentNullException("conversionType");
            }

            if (conversionType.IsGenericType &&
              conversionType.GetGenericTypeDefinition().Equals(typeof(Nullable<>))) {
                if (value == null) {
                    return null;
                }

                NullableConverter nullableConverter = new NullableConverter(conversionType);
                conversionType = nullableConverter.UnderlyingType;
            }

            return Convert.ChangeType(value, conversionType);
        }

    }
    class QuestionXmlHelperException : ApplicationException
    {

        public QuestionXmlHelperException(string Message, string propertyName, string questionType, string xml, Exception innerException)
            : base(Message, innerException) {

            PropertyName = propertyName;
            QuestionType = questionType;
            XmlE = xml;

        }
        public string PropertyName { get; set; }
        public string QuestionType { get; set; }
        public string XmlE { get; set; }

    }
}
