﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SurveyEngine.DataAccess;
using SurveyEngine.DataAccess.Sql;
using System.Configuration;
using SurveyEngine.Model;
using SurveyEngine.Core.Utils;
using SurveyEngine.Core.Questions;

namespace SurveyEngine.Core
{
    public class SqlQuestionRepository : IQuestionRepository
    {
        IList<QuestionTemplate> _templates;
        IList<IQuestion> _questions;

        public SqlQuestionRepository() {
            _templates = SurveyCache.GetQuestionTemplates().ToList();
            _questions = new IQuestion[_templates.Count];
        }
        #region IQuestionRepository Members

        public SurveyEngine.Model.IQuestion GetByIndex(int index) {
            return _questions[index] == null ? _questions[index] = CreateInstance(_templates[index]) : _questions[index];
        }

        public bool IsLast(int index) {
            return index == _questions.Count - 1;
        }

        public int Count() {
            return _questions.Count;
        }

        public IList<SurveyEngine.Model.IQuestion> GetAll() {
            return _questions;
        }

        #endregion

        private static IQuestion CreateInstance(QuestionTemplate template) {
            if (template.QuestionData.Name != "question")
                throw new InvalidOperationException("Invalid question template xml");

            var questionTypeName = template.QuestionData.Attribute("type").Value;
            var questionType = GetQuestionType(questionTypeName);
            var question = (IQuestion)Activator.CreateInstance(questionType, template.Key);
            question.FillQuestion(template.QuestionData);

            return question;
        }

        private static Type GetQuestionType(string questionType) {
            switch (questionType) {
                case "Matrix":
                    return typeof(MatrixQuestion<MatrixRow, MatrixVariant>);
                case "CheckList":
                    return typeof(CheckListQuestion<CheckListRow>);
                default:
                    throw new NotSupportedException("The question type " + questionType + " is not supported");
            }
        }

        #region IQuestionRepository Members


        public SurveyConstraintsCollection Constaints() {
            return new SurveyConstraintsCollection();
        }

        public IQuestion GetByKey(string key) {
            throw new NotImplementedException();
        }

        #endregion
    }

    public static class SurveyCache
    {
        const string c_sQuestionTemplatesName = "SurveyQuestionTemplates";

        public static void Clear() {
            lock (typeof(SurveyCache)) {
                List<string> keys = new List<string>();

                var enumerator = HttpContext.Current.Cache.GetEnumerator();

                // copy all keys that currently exist in Cache
                while (enumerator.MoveNext()) {
                    keys.Add(enumerator.Key.ToString());
                }
                // delete every key from cache
                foreach (var key in keys) {
                    HttpContext.Current.Cache.Remove(key);
                }
            }
        }

        public static IEnumerable<QuestionTemplate> GetQuestionTemplates() {
            lock (typeof(SurveyCache)) {
                var casheObj = HttpContext.Current.Cache[c_sQuestionTemplatesName] as IEnumerable<QuestionTemplate>;
                if (casheObj == null) {
                    using (var dc = new SurveyDataContext(ConfigurationManager.ConnectionStrings["Linq2Sql"].ConnectionString)) {
                        HttpContext.Current.Cache.Add(c_sQuestionTemplatesName, 
                            casheObj = dc.QuestionTemplates.Where(qt => !qt.Disabled).OrderBy(qt => qt.Id).OrderBy(qt => qt.Order).ToList(),
                            null, DateTime.Now.AddMinutes(30),
                            TimeSpan.Zero,
                            System.Web.Caching.CacheItemPriority.Default,
                            null);
                    }
                }
                return casheObj;
            }
        }
    }
}
