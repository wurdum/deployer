﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SurveyEngine.Core;
using SurveyEngine.Core.Questions;

namespace SurveyEngine.Core.Questions
{
    public class MaxDiffQuestion<TPage> : QuestionBase<MaxDiffQuestion<TPage>>, IOrderableVariantsQuestion
        where TPage : IMaxDiffPage, new()
    {
        public MaxDiffQuestion(IQuestionData data) {
            TemplateName = "MaxDiff";
            Key = data.Key;
            QuestionText = data.Text;
            Pages = data.Rows.Select(r => new TPage { PageId = r.Id }).ToList();
        }
        public int PageSize { get { return 1; } }
        public int PageIndex { get; set; }

        [AnswersTable, QuestionTable]
        public IEnumerable<TPage> Pages { get; set; }

        public string LeftScaleHelpText { get; set; }
        public string RightScaleHelpText { get; set; }

        public virtual TPage GetMaxDiffPage() {
            return Pages.Where(r => !r.IsHidden).OrderBy(r => r.Order).Skip(PageIndex).FirstOrDefault();
        }

        public override int PageCount {
            get { return Pages.Count(); }
        }

        public override int AproximatlyPageCount {
            get { return Pages.Count(); }
        }

        protected override bool Validate(SurveyEngine.Model.QuestionEventArgs args, IList<string> modelErrors) {
            PageIndex = args.PageIndex;
            return true;
        }
        protected override void BeforeAsk(SurveyEngine.Model.QuestionEventArgs args) {
            base.BeforeAsk(args);
            if (!HaveToSkip)
                HaveToSkip = Pages.Where(r => !r.IsHidden).Count() == 0;
        }
        protected override void Asking(SurveyEngine.Model.QuestionEventArgs args) {
            base.Asking(args);
            PageIndex = args.PageIndex;
        }


        #region IOrderableVariantsQuestion Members

        public OrderKind VariantsOrderKind {
            get {
                throw new NotImplementedException();
            }
            set {
                throw new NotImplementedException();
            }
        }

        public int? FirstOrderingVariantIndex {
            get {
                throw new NotImplementedException();
            }
            set {
                throw new NotImplementedException();
            }
        }

        public int? LastOrderingVariantIndex {
            get {
                throw new NotImplementedException();
            }
            set {
                throw new NotImplementedException();
            }
        }

        public void ApplyVariantsOrder(IEnumerable<int> variantsOrderKeys) {
            throw new NotImplementedException();
        }

        public void ApplyVariantsOrdering() {
            throw new NotImplementedException();
        }

        #endregion
    }

    public interface IMaxDiffPage
    {
        int PageId { get; set; }
        
        int? Order { get; set; }
        bool IsHidden { get; set; }

        int? Least { get; set; }
        int? Most { get; set; }

        IEnumerable<KeyValuePair<int, string>> Variants { get; set; }
    }

    public class MaxDiffPage : IMaxDiffPage
    {
        public MaxDiffPage() { }
        public MaxDiffPage(int pageId) {
            PageId = pageId;
        }

        [IsRowNameField]
        public int PageId { get; set; }
        [QuestionField]
        public int? Order { get; set; }
        [QuestionField]
        public bool IsHidden { get; set; }
        [AnswerField]
        public int? Least { get; set; }
        [AnswerField]
        public int? Most { get; set; }

        public IEnumerable<KeyValuePair<int, string>> Variants { get; set; }
    }


}
