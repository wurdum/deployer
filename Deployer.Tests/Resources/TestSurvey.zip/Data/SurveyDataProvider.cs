﻿using System;
using System.Collections.Generic;
using SurveyEngine.Core.CSV;
using SurveyEngine.Core.Questions;
using SurveyEngine.Core.Source;

namespace ChartDemo.Data
{
    public class SurveyDataProvider : SourceProvider<SurveyDataProvider>
    {
        public SurveyDataProvider() : base("SurveyExample Data Provider") {}

        public static IEnumerable<IEntity> GetDataForQuestion(string questionKey) {
            switch (questionKey) {
                case "Q1":
                    return Q1Variants();
                case "Q2":
                    return Q2Variants();
                case "Q3":
                    return Q3Variants();
                default:
                    throw new ArgumentException("Expected 'Q1', 'Q2' or 'Q3' values", "questionKey");
            }
        }

        public static IEnumerable<IEntity> Q1Variants() {
            return CSVDataReader.GetDataEx("Q1Variants");
        }
        public static IEnumerable<IEntity> Q2Variants() {
            return CSVDataReader.GetDataEx("Q2Variants");
        }
        public static IEnumerable<IEntity> Q3Variants() {
            return CSVDataReader.GetDataEx("Q3Variants");
        }
    }
}