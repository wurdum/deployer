﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SurveyEngine.Core.Constraints;

namespace ChartDemo.Data
{
    public static class ChartsDataProvider
    {
        public static string GetAnswersAsJs(bool attachValueToLabel) {
            var constraint = SurveyConstraints.Constraints.Single(c => c.Name.Equals("Answers"));
            var conditions = constraint.GetStatistic();
            var answerItems = (from condition in conditions 
                               let pv = condition.PropertyValues.First() 
                               let description = constraint.GetValueDescription(new KeyValuePair<string, string>(pv.Key, pv.Value)) 
                               select new AnswerItem {Id = pv.Value, Text = description, Count = condition.Count}).ToList();

            var totalAnswers = answerItems.Sum(ai => ai.Count);
            foreach (var item in answerItems)
                item.CalculateSlice(totalAnswers);

            if (answerItems.All(ai => Math.Abs(ai.Slice - 0) < 0.0001))
                foreach (var answerItem in answerItems)
                    answerItem.Slice = Math.Round((double) 100/answerItems.Count, 1);

            var leftToHundred = 100 - answerItems.Sum(i => i.Slice);
            answerItems.Last().Slice = answerItems.Last().Slice + Math.Round(leftToHundred, 1);

            if (attachValueToLabel)
                foreach (var item in answerItems)
                    item.Text = string.Format("{0} - {1}%", item.Text, item.Slice);

            return AsJsArray(answerItems);
        }

        private static string AsJsArray(IEnumerable<AnswerItem> answerItems) {
            var jsArray = new StringBuilder();
            foreach (var answer in answerItems.OrderBy(ai => ai.Id))
                jsArray.Append(string.Format("[\"{0}\", {1}], ", answer.Text, answer.Slice));

            var lenthWithoutLastComma = jsArray.Length - 2;
            return lenthWithoutLastComma > 0 ? jsArray.ToString(0, lenthWithoutLastComma) : "[]";
        }
    }

    public class AnswerItem
    {
        public string Id { get; set; }
        public string Text { get; set; }
        public int Count { get; set; }
        public double Slice { get; set; }

        public void CalculateSlice(int totalAnswers) {
            Slice = totalAnswers != 0 ? Math.Round(((double) Count / totalAnswers) * 100, 1) : 0;
        }
    }
}